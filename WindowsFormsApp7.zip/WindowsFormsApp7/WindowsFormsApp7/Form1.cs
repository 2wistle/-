﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.Linq;
using System.Data.SqlClient;



namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        static string conStr = @"Data Source=ADMIN-PC\SQLEXPRESS;Initial Catalog=sataev; Integrated Security=True";

        DataContext context = new DataContext(conStr);

        public Form1()
        {
            InitializeComponent();

            Table<Мат> Материал = context.GetTable<Мат>();
            dataGridView2.DataSource = Материал.ToList();

            Table<Меб> Мебель = context.GetTable<Меб>();
            dataGridView4.DataSource = Мебель.ToList();

            Table<Зак> Заказ = context.GetTable<Зак>();
            dataGridView1.DataSource = Мебель.ToList();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sataevDataSet.Мебель". При необходимости она может быть перемещена или удалена.
            this.мебельTableAdapter.Fill(this.sataevDataSet.Мебель);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sataevDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.sataevDataSet.Города);



        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Мат cu = new Мат { Материал = textBox1.Text, Вес = textBox4.Text };
            context.GetTable<Мат>().InsertOnSubmit(cu);
            context.SubmitChanges();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            var f = context.GetTable<Меб>().Where(x => x.Имя.Contains(Convert.ToString(comboBox3.SelectedValue)));
            dataGridView4.DataSource = f.ToList();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Мат cus = context.GetTable<Мат>().FirstOrDefault(x => x.ID == Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value));
            cus.Материал = textBox2.Text;
            cus.Вес = textBox3.Text;
            context.SubmitChanges();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
           
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox3.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                        dataGridView1.Rows[i].Selected = false;
                    }
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox3.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
                        dataGridView1.Rows[i].Selected = false;
                    }
                }
            }
        }
    }
}
   

